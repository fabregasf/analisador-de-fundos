# Sistema de geração de relatório de Fundos imobiliários

O sistema foi criado em Python, e funciona da seguinte forma: 

1 - O usuário deve digitar o Ticker do fundo na bolsa de valores. Exemplo: CPTS11, VILG11 etc entre virgulas

O sistema gera gráficos com análise fundamentalista, mais estatística mostrando tendências da empresa, por exemplo: Geração de caixa histórico, Investimentos (Capex), Novas aquisições e outros. 
